import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateTutorResponse, suggestResources } from "./ai";
import { insertChatSchema, insertPracticeProblemSchema, insertSharedResourceSchema } from "@shared/schema";

export function registerRoutes(app: Express): Server {
  // Create a new chat
  app.post("/api/chat", async (req, res) => {
    try {
      const chatData = insertChatSchema.parse(req.body);
      const response = await generateTutorResponse(
        chatData.subject, 
        chatData.question,
        req.body.mediaType,
        req.body.mediaContent
      );

      const chat = await storage.createChat({
        ...chatData,
        userId: 1, // Default user ID since we removed auth
        response
      });

      res.json(chat);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Get chat history
  app.get("/api/chats", async (req, res) => {
    const chats = await storage.getChatsByUserId(1); // Default user ID
    res.json(chats);
  });

  // Progress tracking endpoints
  app.get("/api/progress", async (req, res) => {
    const progress = await storage.getAllProgress(1); // Default user ID
    res.json(progress);
  });

  app.get("/api/progress/:subject", async (req, res) => {
    const progress = await storage.getProgress(1, req.params.subject);
    if (!progress) {
      return res.status(404).json({ message: "Progress not found" });
    }
    res.json(progress);
  });

  // Practice problems endpoints
  app.post("/api/practice", async (req, res) => {
    try {
      const problemData = insertPracticeProblemSchema.parse(req.body);
      const problem = await storage.createPracticeProblem({
        ...problemData,
        userId: 1
      });
      res.json(problem);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/practice/:subject", async (req, res) => {
    const problems = await storage.getPracticeProblemsBySubject(1, req.params.subject);
    res.json(problems);
  });

  // Shared resources endpoints
  app.post("/api/resources", async (req, res) => {
    try {
      const resourceData = insertSharedResourceSchema.parse(req.body);
      const resource = await storage.createSharedResource({
        ...resourceData,
        userId: 1
      });
      res.json(resource);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/resources", async (req, res) => {
    const subject = req.query.subject as string | undefined;
    const resources = await storage.getSharedResources(subject);
    res.json(resources);
  });

  // Get AI-suggested resources
  app.get("/api/resources/suggestions", async (req, res) => {
    const { subject, topic } = req.query;
    if (typeof subject !== "string" || typeof topic !== "string") {
      return res.status(400).json({ message: "Invalid query parameters" });
    }

    try {
      const resources = await suggestResources(subject, topic);
      res.json(resources);
    } catch (error) {
      res.status(500).json({ message: "Failed to get resources" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}