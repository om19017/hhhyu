import { 
  users, type User, type InsertUser, 
  type Chat, type InsertChat,
  type Progress, type InsertProgress,
  type PracticeProblem, type InsertPracticeProblem,
  type SharedResource, type InsertSharedResource
} from "@shared/schema";
import createMemoryStore from "memorystore";
import type { Store } from "express-session";
import session from "express-session";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Chat methods
  createChat(chat: InsertChat & { userId: number, response: string }): Promise<Chat>;
  getChatsByUserId(userId: number): Promise<Chat[]>;

  // Progress tracking methods
  getProgress(userId: number, subject: string): Promise<Progress | undefined>;
  updateProgress(userId: number, subject: string, isCorrect: boolean): Promise<Progress>;
  getAllProgress(userId: number): Promise<Progress[]>;

  // Practice problems methods
  createPracticeProblem(problem: InsertPracticeProblem & { userId: number }): Promise<PracticeProblem>;
  getPracticeProblemsBySubject(userId: number, subject: string): Promise<PracticeProblem[]>;

  // Shared resources methods
  createSharedResource(resource: InsertSharedResource & { userId: number }): Promise<SharedResource>;
  getSharedResources(subject?: string): Promise<SharedResource[]>;

  sessionStore: Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private chats: Map<number, Chat>;
  private progress: Map<string, Progress>;
  private practiceProblems: Map<number, PracticeProblem>;
  private sharedResources: Map<number, SharedResource>;

  currentUserId: number;
  currentChatId: number;
  currentProblemId: number;
  currentResourceId: number;
  sessionStore: Store;

  constructor() {
    this.users = new Map();
    this.chats = new Map();
    this.progress = new Map();
    this.practiceProblems = new Map();
    this.sharedResources = new Map();
    this.currentUserId = 1;
    this.currentChatId = 1;
    this.currentProblemId = 1;
    this.currentResourceId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  // Existing methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createChat(chat: InsertChat & { userId: number, response: string }): Promise<Chat> {
    const id = this.currentChatId++;
    const newChat: Chat = {
      ...chat,
      id,
      createdAt: new Date()
    };
    this.chats.set(id, newChat);
    // Update progress when a chat is created
    await this.updateProgress(chat.userId, chat.subject, true);
    return newChat;
  }

  async getChatsByUserId(userId: number): Promise<Chat[]> {
    return Array.from(this.chats.values())
      .filter(chat => chat.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // New methods for progress tracking
  async getProgress(userId: number, subject: string): Promise<Progress | undefined> {
    const key = `${userId}-${subject}`;
    return this.progress.get(key);
  }

  async updateProgress(userId: number, subject: string, isCorrect: boolean): Promise<Progress> {
    const key = `${userId}-${subject}`;
    const existing = await this.getProgress(userId, subject);

    const progress: Progress = {
      id: existing?.id ?? this.progress.size + 1,
      userId,
      subject,
      questionsAsked: (existing?.questionsAsked ?? 0) + 1,
      correctAnswers: (existing?.correctAnswers ?? 0) + (isCorrect ? 1 : 0),
      lastActivity: new Date(),
    };

    this.progress.set(key, progress);
    return progress;
  }

  async getAllProgress(userId: number): Promise<Progress[]> {
    return Array.from(this.progress.values())
      .filter(progress => progress.userId === userId)
      .sort((a, b) => b.lastActivity.getTime() - a.lastActivity.getTime());
  }

  // New methods for practice problems
  async createPracticeProblem(problem: InsertPracticeProblem & { userId: number }): Promise<PracticeProblem> {
    const id = this.currentProblemId++;
    const newProblem: PracticeProblem = {
      ...problem,
      id,
      createdAt: new Date()
    };
    this.practiceProblems.set(id, newProblem);
    return newProblem;
  }

  async getPracticeProblemsBySubject(userId: number, subject: string): Promise<PracticeProblem[]> {
    return Array.from(this.practiceProblems.values())
      .filter(problem => problem.userId === userId && problem.subject === subject)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // New methods for shared resources
  async createSharedResource(resource: InsertSharedResource & { userId: number }): Promise<SharedResource> {
    const id = this.currentResourceId++;
    const newResource: SharedResource = {
      ...resource,
      id,
      createdAt: new Date()
    };
    this.sharedResources.set(id, newResource);
    return newResource;
  }

  async getSharedResources(subject?: string): Promise<SharedResource[]> {
    let resources = Array.from(this.sharedResources.values());
    if (subject) {
      resources = resources.filter(resource => resource.subject === subject);
    }
    return resources.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
}

export const storage = new MemStorage();