import OpenAI from "openai";

// Using gpt-3.5-turbo as it's a stable and widely available model
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function generateTutorResponse(subject: string, question: string): Promise<string> {
  const systemPrompt = `You are an expert tutor in ${subject}. Provide a clear, step-by-step explanation that helps the student understand the concept and arrive at the answer. Include relevant examples and cite sources when appropriate. Focus on building understanding rather than just giving the answer.`;

  const response = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: question }
    ],
    temperature: 0.7,
    max_tokens: 1000
  });

  return response.choices[0].message.content || "I apologize, but I couldn't generate a response. Please try rephrasing your question.";
}

export async function suggestResources(subject: string, topic: string): Promise<{
  resources: Array<{title: string, description: string, url?: string}>
}> {
  const response = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: "You are an educational resource expert. Suggest high-quality learning resources for the given subject and topic. Include a mix of online courses, textbooks, videos, and practice materials."
      },
      {
        role: "user",
        content: `Suggest learning resources for ${subject}, specifically about ${topic}. Provide JSON response with an array of resources, each having a title and description, and optionally a URL.`
      }
    ],
    response_format: { type: "json_object" }
  });

  return JSON.parse(response.choices[0].message.content || "{}") as { resources: Array<{title: string, description: string, url?: string}> };
}