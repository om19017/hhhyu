import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export async function generateTutorResponse(subject: string, question: string, mediaType?: "voice" | "image", mediaContent?: string): Promise<string> {
  const model = genAI.getGenerativeModel({ model: mediaType === "image" ? "gemini-pro-vision" : "gemini-pro" });

  const systemPrompt = `You are an expert tutor in ${subject}. Provide a clear, step-by-step explanation that helps the student understand the concept and arrive at the answer. Include relevant examples and cite sources when appropriate. Focus on building understanding rather than just giving the answer.`;

  try {
    let result;

    if (mediaType === "image" && mediaContent) {
      // Extract base64 data from the data URL
      const base64Data = mediaContent.split(',')[1];

      result = await model.generateContent([
        systemPrompt,
        {
          inlineData: {
            mimeType: "image/jpeg",
            data: base64Data
          }
        },
        "Please analyze this image and explain the question or concept shown."
      ]);
    } else {
      const prompt = `${systemPrompt}\n\nQuestion: ${question}`;
      result = await model.generateContent(prompt);
    }

    const response = await result.response;
    return response.text();
  } catch (error: any) {
    console.error('Error generating tutor response:', error);
    return "I apologize, but I couldn't generate a response. Please try rephrasing your question.";
  }
}

export async function suggestResources(subject: string, topic: string): Promise<{
  resources: Array<{title: string, description: string, url?: string}>
}> {
  const model = genAI.getGenerativeModel({ model: "gemini-pro" });

  const prompt = `Suggest learning resources for ${subject}, specifically about ${topic}. Format the response as a JSON object with an array of resources, each having a title, description, and optionally a URL. Focus on high-quality educational content.`;

  try {
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return JSON.parse(response.text()) as { resources: Array<{title: string, description: string, url?: string}> };
  } catch (error: any) {
    console.error('Error suggesting resources:', error);
    return { resources: [] };
  }
}