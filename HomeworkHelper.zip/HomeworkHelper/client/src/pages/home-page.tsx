import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertChatSchema, type InsertChat, type Chat, type Progress } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, BarChart2, Brain, Sparkles, History } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { MediaInput } from "@/components/media-input";

const subjects = [
  "Mathematics",
  "Physics",
  "Chemistry",
  "Biology",
  "Computer Science",
  "History",
  "Literature",
  "Geography",
];

export default function HomePage() {
  const queryClient = useQueryClient();

  const form = useForm<InsertChat>({
    resolver: zodResolver(insertChatSchema),
    defaultValues: {
      subject: "",
      question: "",
    },
  });

  const chatMutation = useMutation({
    mutationFn: async (data: InsertChat & { mediaType?: "voice" | "image", mediaContent?: string }) => {
      const res = await apiRequest("POST", "/api/chat", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
      form.reset();
    },
  });

  const { data: chats = [], isLoading: isLoadingChats } = useQuery<Chat[]>({
    queryKey: ["/api/chats"],
  });

  const { data: progress = [], isLoading: isLoadingProgress } = useQuery<Progress[]>({
    queryKey: ["/api/progress"],
  });

  const getProgressForSubject = (subject: string) => {
    const subjectProgress = progress.find(p => p.subject === subject);
    if (!subjectProgress) return { questionsAsked: 0, correctAnswers: 0 };
    return {
      questionsAsked: subjectProgress.questionsAsked,
      correctAnswers: subjectProgress.correctAnswers,
    };
  };

  const calculateAccuracy = (subject: string) => {
    const { questionsAsked, correctAnswers } = getProgressForSubject(subject);
    if (questionsAsked === 0) return 0;
    return (correctAnswers / questionsAsked) * 100;
  };

  const handleMediaSubmit = (content: string, type: "voice" | "image") => {
    const subject = form.getValues("subject");
    if (!subject) {
      alert("Please select a subject first");
      return;
    }

    chatMutation.mutate({
      subject,
      question: type === "image" ? "Image analysis request" : "Voice question",
      mediaType: type,
      mediaContent: content,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-primary/5 flex flex-col">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Brain className="h-8 w-8 text-primary" />
              <div className="flex flex-col">
                <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/50 bg-clip-text text-transparent">
                  AI Tutor
                </h1>
                <span className="text-xs text-muted-foreground">by aiexplore.fun</span>
              </div>
            </div>
            <Button variant="outline" onClick={() => window.location.reload()} className="gap-2">
              <Sparkles className="h-4 w-4" />
              New Session
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 grid gap-8 md:grid-cols-[1fr,400px] flex-grow"> {/* Added flex-grow */}
        <div className="space-y-8">
          <Card className="border-primary/20 shadow-lg shadow-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Ask a Question
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit((data) => chatMutation.mutate(data))} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Subject</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a subject" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {subjects.map((subject) => (
                              <SelectItem key={subject} value={subject}>
                                {subject}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="question"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Your Question</FormLabel>
                        <FormControl>
                          <div className="space-y-2">
                            <Input {...field} placeholder="Type your question here..." />
                            <MediaInput onMediaSubmit={handleMediaSubmit} />
                          </div>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full" disabled={chatMutation.isPending}>
                    {chatMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    Ask Question
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <ScrollArea className="h-[600px] pr-4">
            {isLoadingChats ? (
              <div className="flex justify-center p-4">
                <Loader2 className="h-6 w-6 animate-spin" />
              </div>
            ) : (
              <div className="space-y-4">
                {chats.map((chat) => (
                  <Card key={chat.id} className="hover:shadow-md transition-shadow duration-200">
                    <CardContent className="pt-6">
                      <div className="mb-4">
                        <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                          <History className="h-4 w-4" />
                          {chat.subject} • {new Date(chat.createdAt).toLocaleString()}
                        </div>
                        <p className="mt-2 font-medium">{chat.question}</p>
                      </div>
                      <div className="pl-4 border-l-2 border-primary/20">
                        <p className="whitespace-pre-wrap">{chat.response}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>

        <div className="space-y-6">
          <Card className="border-primary/20 shadow-lg shadow-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart2 className="h-5 w-5" />
                Learning Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingProgress ? (
                <div className="flex justify-center p-4">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div>
              ) : (
                <div className="space-y-6">
                  {subjects.map((subject) => {
                    const { questionsAsked, correctAnswers } = getProgressForSubject(subject);
                    if (questionsAsked === 0) return null;

                    return (
                      <div key={subject} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium">{subject}</span>
                          <span className="text-muted-foreground">
                            {correctAnswers}/{questionsAsked} correct
                          </span>
                        </div>
                        <ProgressBar value={calculateAccuracy(subject)} className="h-2" />
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-primary/20 shadow-lg shadow-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="h-2 w-2 rounded-full bg-primary"></div>
                  Questions Asked: {chats.length}
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="h-2 w-2 rounded-full bg-primary"></div>
                  Active Subjects: {progress.length}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="mt-auto py-6 border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            Developed by{" "}
            <a
              href="https://aiexplore.fun"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-primary hover:text-primary/80 transition-colors"
            >
              aiexplore.fun
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}